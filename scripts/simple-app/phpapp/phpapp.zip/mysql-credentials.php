<?php
$servername = "STUB_DBMACHINE_IP";
$username = "STUB_DATABASE_USER";
$password = "STUB_DATABASE_PASSWORD";
$database = "STUB_DATABASE_DATABASENAME";
$port = "STUB_MYSQL_PORT";
?>
