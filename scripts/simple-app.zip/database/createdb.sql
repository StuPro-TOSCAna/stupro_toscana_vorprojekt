CREATE database STUB_DATABASE_DATABASENAME;
create table STUB_DATABASE_DATABASENAME.tasks
   (id int not null unique auto_increment,
      task varchar(255),
      primary key (id)
   );

